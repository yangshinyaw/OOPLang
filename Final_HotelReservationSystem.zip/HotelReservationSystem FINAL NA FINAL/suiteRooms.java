import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class suiteRooms extends JFrame implements ActionListener
{
    JButton menu;
    
    public suiteRooms()
    {

        ImageIcon imageB = new ImageIcon(getClass().getResource("HotelBanner.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(0,-210,1000,800);
        
        JLabel text1 = new JLabel("Experience Your Dreams");
        text1.setFont(new Font("Arial", 1, 25));
        text1.setForeground(new Color(0,0,0));
        text1.setBounds(330,320,800,100);
        
        ImageIcon imagePackage = new ImageIcon(getClass().getResource("SuiteRoom.png"));
        JLabel picturePackage = new JLabel(imagePackage);
        picturePackage.setBounds(-5,135,1000,800);
 
        menu = new JButton("Back to Menu");
        menu.setFont(new Font("Century Schoolbook", 0, 14));
        menu.setBounds(422,715,150,25);
        menu.addActionListener(this);
        
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);
 
        JLabel rightsName  = new JLabel("All Rights Reserved");
        rightsName .setFont(new Font("Arial", 0, 13));
        rightsName .setForeground(new Color(102,102,102));
        rightsName .setBounds(20,705,1000,50);

        setTitle("SUITE ROOMS");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
       
        add(text1);
        
        add(rightsName );
        
        add(picturePackage);
        add(backgroundBelow);
        add(menu);
        add(banner);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == menu){
           this.dispose();
        }
    }

    public static void main(String[] args){
        new executiveRooms().show();
        
    }
}
