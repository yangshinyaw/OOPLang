public class Executive extends Room {
    String lounge; //Basic or VIP
    String balcony; //Pool View or Beach View
    
    public Executive(String lounge, String balcony, int roomNumber, int roomCapacity, int size, boolean available){
        super(roomNumber, roomCapacity, size, available);
        this.rate = 5550;
        this.lounge = lounge;
        this.balcony = balcony;
    }
}
