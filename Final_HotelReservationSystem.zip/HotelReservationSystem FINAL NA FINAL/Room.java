public class Room {
    int roomNumber;
    int roomCapacity;
    int size;
    int rate;
    boolean available;
    
    public Room(int roomNumber, int roomCapacity, int size, boolean available){
        this.rate = 2500;
        this.roomNumber = roomNumber;
        this.roomCapacity = roomCapacity;
        this.size = size;
        this.available = available;
    }
}