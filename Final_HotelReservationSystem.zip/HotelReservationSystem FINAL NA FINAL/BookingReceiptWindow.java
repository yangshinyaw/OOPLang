import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BookingReceiptWindow extends JFrame implements ActionListener{
    JFrame BookingReceiptFrame;
    String fName, lName, contactNumber, address, email;
    JLabel fNameLabel, lNameLabel, numLabel, addressLabel, emailLabel, 
        companyTitle, firstNameLabel, lastNameLabel,cLabel,eLabel,addrsLabel,
        roomTypeLabel, rTypeLabel,stayDurationLabel, durationLabel, totalBillLabel,
        billLabel;
    JButton confirmButton, cancelButton;
    Font myFont = new Font("Stencil",Font.BOLD,25);
    Font myFont2 = new Font("Century Schoolbook",Font.BOLD,15);

    public BookingReceiptWindow(){
        
    }
    
    public BookingReceiptWindow(String fName, String lName, String contactNumber, String address, String email, String roomType, String stayDuration){
        this.fName = fName;
        this.lName = lName;
        this.contactNumber = contactNumber;
        this.address = address;
        this.email = email;
        
        BookingReceiptFrame = new JFrame("Your Receipt!");
        BookingReceiptFrame.setSize(500,800);
        BookingReceiptFrame.getContentPane();
        BookingReceiptFrame.setLayout(new BorderLayout(10, 20));
        BookingReceiptFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        BookingReceiptFrame.setBounds(1000,100, 550,400);
        BookingReceiptFrame.setLayout(null);
        BookingReceiptFrame.setResizable(false);
        
        fNameLabel = new JLabel(fName);
        fNameLabel.setBounds(150,60,500,50);
        fNameLabel.setFont(myFont2);
        BookingReceiptFrame.add(fNameLabel);
        firstNameLabel = new JLabel("First Name: ");
        firstNameLabel.setBounds(40,60,100,50);
        firstNameLabel.setFont(myFont2);
        BookingReceiptFrame.add(firstNameLabel);
        
        lNameLabel = new JLabel(lName);
        lNameLabel.setBounds(150,80,500,50);
        lNameLabel.setFont(myFont2);
        BookingReceiptFrame.add(lNameLabel);
        lastNameLabel = new JLabel("Last Name: ");
        lastNameLabel.setBounds(40,80,100,50);
        lastNameLabel.setFont(myFont2);
        BookingReceiptFrame.add(lastNameLabel);
        
        numLabel = new JLabel(contactNumber);
        numLabel.setBounds(150,100,500,50);
        numLabel.setFont(myFont2);
        BookingReceiptFrame.add(numLabel);
        cLabel = new JLabel("Contact #: ");
        cLabel.setFont(myFont2);
        cLabel.setBounds(40,100,100,50);
        BookingReceiptFrame.add(cLabel);
        
        addressLabel = new JLabel(address);
        addressLabel.setBounds(150,120,500,50);
        addressLabel.setFont(myFont2);
        BookingReceiptFrame.add(addressLabel);
        addrsLabel = new JLabel("Address: ");
        addrsLabel.setBounds(40,120,100,50);
        addrsLabel.setFont(myFont2);
        BookingReceiptFrame.add(addrsLabel);
        
        emailLabel = new JLabel(email);
        emailLabel.setBounds(150,140,500,50);
        emailLabel.setFont(myFont2);
        BookingReceiptFrame.add(emailLabel);
        eLabel = new JLabel("E-mail: ");
        eLabel.setBounds(40,140,100,50);
        eLabel.setFont(myFont2);
        BookingReceiptFrame.add(eLabel);
        
        roomTypeLabel = new JLabel(roomType);
        roomTypeLabel.setBounds(150,160,500,50);
        roomTypeLabel.setFont(myFont2);
        BookingReceiptFrame.add(roomTypeLabel);
        rTypeLabel = new JLabel("Room Type: ");
        rTypeLabel.setBounds(40,160,100,50);
        rTypeLabel.setFont(myFont2);
        BookingReceiptFrame.add(rTypeLabel);
        
        stayDurationLabel = new JLabel(stayDuration);
        stayDurationLabel.setBounds(150,180,500,50);
        stayDurationLabel.setFont(myFont2);
        BookingReceiptFrame.add(stayDurationLabel);
        durationLabel = new JLabel("Duration: ");
        durationLabel.setBounds(40,180,100,50);
        durationLabel.setFont(myFont2);
        BookingReceiptFrame.add(durationLabel);
        
        //Compute bill of user
        double bill = computeBill(roomType, stayDuration);
        totalBillLabel = new JLabel("Php: "+bill);
        totalBillLabel.setBounds(150,200,500,50);
        totalBillLabel.setFont(myFont2);  
        BookingReceiptFrame.add(totalBillLabel);
        billLabel = new JLabel("TOTAL: ");
        billLabel.setBounds(40,200,100,50);
        billLabel.setFont(myFont2);
        BookingReceiptFrame.add(billLabel);
        
        companyTitle = new JLabel("ELIS ALIAS HOTEL");
        companyTitle.setFont(myFont);
        companyTitle.setBounds(150,0,600,100);
        BookingReceiptFrame.add(companyTitle);
        
        confirmButton = new JButton("Confrim");
        confirmButton.setFont(myFont2);
        confirmButton.setBounds(40,300,100,50);
        BookingReceiptFrame.add(confirmButton);
        confirmButton.addActionListener(this);
        
        cancelButton = new JButton("Cancel");
        cancelButton.setFont(myFont2);
        cancelButton.setBounds(250,300,100,50);
        BookingReceiptFrame.add(cancelButton);
        cancelButton.addActionListener(this);
        
        BookingReceiptFrame.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == confirmButton){
            BookingReceiptFrame.dispose();
            new UI();
        }else if (e.getSource() == cancelButton){
            BookingReceiptFrame.dispose();
            new BookingWindow();
        }
    }
    
    public double computeBill(String roomType, String stayDuration){
        double rate, bill;
        if (stayDuration == "1 Week"){
            stayDuration = "268 Hours";
        }
        stayDuration = stayDuration.substring(0,stayDuration.length()-6);
        if (roomType == "Guest"){
            rate = 2500;
        }else if (roomType == "Suite"){
            rate = 3750;
        }else{
            rate = 5550;
        }
        
        int hours = Integer.parseInt(stayDuration);
        bill = rate * hours;
    
        return bill;
    }
    
    public static void main(String[] args){
        new BookingReceiptWindow();
    }
}
