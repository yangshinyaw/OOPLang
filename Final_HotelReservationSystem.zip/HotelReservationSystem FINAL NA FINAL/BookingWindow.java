import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class BookingWindow extends JFrame implements ActionListener
{
    Hotel thishotel = new Hotel(); //THIS CREATES A LIST OF HOTEL ROOM
    
    JFrame bookingFrame;
    JPanel titlePanel;
    JButton bookButton, previousButton, viewRoomsButton;
    JLabel companyTitle,header,firstNameLabel,lastNameLabel,contactLabel,
    addressLabel, emailLabel, roomTypeLabel, durationLabel;
    JTextField firstNameText, lastNameText,contactText,addressText,emailText;
    String[] roomChoices = {"","Guest", "Suite", "Executive"};     //String[] roomChoices = {"","Guest Room", "Suite", "Executive"};
    final JComboBox<String> cb = new JComboBox<String>(roomChoices);
    String[] durationChoice = {"","6 Hours", "12 Hours", "24 Hours", "48 Hours", "1 Week"};
    final JComboBox<String> dc = new JComboBox<String>(durationChoice);
    Font myFont = new Font("Stencil",Font.BOLD,25);
    Font myFont2 = new Font("Century Schoolbook",Font.BOLD,13);
    
    public BookingWindow(){
     bookingFrame = new JFrame("Booking System");
     titlePanel = new JPanel();
     bookingFrame.setSize(500,800);
     bookingFrame.getContentPane();
     bookingFrame.setLayout(new BorderLayout(10, 20));
     bookingFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
     bookingFrame.setBounds(1000,100, 650,800);
     bookingFrame.setResizable(false);
     bookingFrame.setVisible(true);
     bookingFrame.setLayout(null);
     ImageIcon logo = new ImageIcon("bookLogo.png");
     bookingFrame.setIconImage(logo.getImage());
     companyTitle = new JLabel("Elis Alias Hotel");
     companyTitle.setFont(myFont);
     header = new JLabel("Book at your own Leisure");
     header.setFont(myFont);
     titlePanel.add(companyTitle);
     titlePanel.add(header);
     titlePanel.setLayout(new FlowLayout(FlowLayout.CENTER,28,5));
     bookingFrame.add(titlePanel, BorderLayout.NORTH);
     
     titlePanel.setBounds(20,0,600,70);
    
     
     firstNameLabel = new JLabel("First Name");
     firstNameLabel.setFont(myFont2);
     firstNameLabel.setBounds(50,100,100,50);
     bookingFrame.add(firstNameLabel);
     firstNameText = new JTextField("");
     firstNameText.setFont(myFont2);
     firstNameText.setBounds(50,140,150,25);
     bookingFrame.add(firstNameText);
     
     lastNameLabel = new JLabel("Last Name");
     lastNameLabel.setFont(myFont2);
     lastNameLabel.setBounds(400,100,100,50);
     bookingFrame.add(lastNameLabel);
     lastNameText = new JTextField("");
     lastNameText.setFont(myFont2);
     lastNameText.setBounds(400,140,150,25);
     bookingFrame.add(lastNameText);
     
     contactLabel = new JLabel("Contact Number");
     contactLabel.setFont(myFont2);
     contactLabel.setBounds(50,180,120,50);
     bookingFrame.add(contactLabel);
     contactText = new JTextField("");
     contactText.setFont(myFont2);
     contactText.setBounds(50,220,150,25);
     bookingFrame.add(contactText);
     
     addressLabel = new JLabel("Complete Address");
     addressLabel.setFont(myFont2);
     addressLabel.setBounds(50,260,130,50);
     bookingFrame.add(addressLabel);
     addressText = new JTextField("");
     addressText.setFont(myFont2);
     addressText.setBounds(50,300,150,25);
     bookingFrame.add(addressText);
     
     emailLabel = new JLabel("Email Address");
     emailLabel.setFont(myFont2);
     emailLabel.setBounds(50,340,130,50);
     bookingFrame.add(emailLabel);
     emailText = new JTextField("");
     emailText.setFont(myFont2);
     emailText.setBounds(50,380,150,25);
     bookingFrame.add(emailText);
     
     roomTypeLabel = new JLabel("Room Type");
     roomTypeLabel.setFont(myFont2);
     roomTypeLabel.setBounds(50,420,150,50);
     bookingFrame.add(roomTypeLabel);
     
     cb.setBounds(50,460,100,25);
     bookingFrame.add(cb);
     
     durationLabel = new JLabel("Duration of Stay");
     durationLabel.setFont(myFont2);
     durationLabel.setBounds(400,420,150,50);
     bookingFrame.add(durationLabel);
     
     dc.setBounds(400,460,100,25);
     bookingFrame.add(dc);
     
     bookButton = new JButton("Book");
     bookButton.setFont(myFont2);
     bookButton.setBounds(400,700,120,30);
     bookingFrame.add(bookButton);
     bookButton.addActionListener(this);
     
     previousButton = new JButton("Home");
     previousButton.setFont(myFont2);
     previousButton.setBounds(100,700,120,30);
     bookingFrame.add(previousButton);
     previousButton.addActionListener(this);
     
     viewRoomsButton = new JButton("Rooms");
     viewRoomsButton.setFont(myFont2);
     viewRoomsButton.setBounds(250,700,120,30);
     bookingFrame.add(viewRoomsButton);
     viewRoomsButton.addActionListener(this);
     bookingFrame.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == previousButton){
            bookingFrame.dispose();
            new UI();
        }else if(e.getSource() == bookButton){
            String firstName = firstNameText.getText().trim();            
            String lastName = lastNameText.getText().trim();
            String contactNumber = contactText.getText().trim();
            String address = addressText.getText().trim();
            String email = emailText.getText().trim();
            String roomType = cb.getSelectedItem().toString();
            String stayDuration = dc.getSelectedItem().toString();
            String[] data = {firstName, lastName, contactNumber, address, email, roomType, stayDuration};
            boolean valid = checkBlanks(data);
            if (valid == false){
                JOptionPane.showMessageDialog(null, "Complete All Fields First");
            }else{
                //String matchrom = findMatchRoom(roomType, ivory);
                //System.out.println(matchrom);
                bookingFrame.dispose();
                new BookingReceiptWindow(firstName, lastName, contactNumber, address, email, roomType,stayDuration);
            }
        }else if(e.getSource() == viewRoomsButton){
            String roomType = cb.getSelectedItem().toString().trim();
            if (roomType.length() == 0){
                JOptionPane.showMessageDialog(null, "Select Room Type First");
            }else{
                thishotel.DisplayRoomsWindow(roomType, thishotel);
            }
        }
    }
    
    public boolean checkBlanks(String[] data){
        boolean valid;
        int blank = 0;
        
        for (String item: data){
            if (item.length() == 0){
                blank++;
            }
        }
        
        if (blank > 0){
            valid = false;
        }else{
            valid = true;
        }
        return valid;
    }
    
    public static void main(String[] args){
        new BookingWindow();
    
    
    }
}