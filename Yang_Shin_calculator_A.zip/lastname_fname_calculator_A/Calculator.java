import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Calculator extends JFrame
{
    JButton calculateButton = new JButton();
    JButton exitButton = new JButton();
    
    JLabel operand1Label = new JLabel();
    JLabel operatorLabel = new JLabel();
    JLabel operand2Label = new JLabel();
    JLabel resultLabel = new JLabel();
    
    JTextField operand1TextField = new JTextField();
    JTextField operatorTextField = new JTextField();
    JTextField operand2TextField = new JTextField();
    JTextField resultTextField = new JTextField();
    
    public Calculator(){
        setTitle("Simple Calculator");
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        calculateButton.setText("Calculate");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        getContentPane().add(calculateButton, gridConstraints);
        
        calculateButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                calculateButtonActionPerformed(e);
            }
            
        });
        
        exitButton.setText("Exit");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        getContentPane().add(exitButton, gridConstraints);
        
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                exitButtonActionPerformed(e);
            }
            
        });
        
        operand1Label.setText("Operand 1: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(operand1Label, gridConstraints);
        
        operatorLabel.setText("Operator: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        getContentPane().add(operatorLabel, gridConstraints);
        
        operand2Label.setText("Operand 2: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(operand2Label, gridConstraints);
        
        resultLabel.setText("Result: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        getContentPane().add(resultLabel, gridConstraints);
        
        operand1TextField.setText("");
        operand1TextField.setColumns(15);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        getContentPane().add(operand1TextField, gridConstraints);
        
        operatorTextField.setText("");
        operatorTextField.setColumns(15);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        getContentPane().add(operatorTextField, gridConstraints);
        
        operand2TextField.setText("");
        operand2TextField.setColumns(15);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        getContentPane().add(operand2TextField, gridConstraints);
        
        resultTextField.setText("");
        resultTextField.setColumns(15);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        getContentPane().add(resultTextField, gridConstraints);
        
        pack();
        
        
        
        
    }
    private void exitButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "GoodBye!");
    }
    private void calculateButtonActionPerformed(ActionEvent e){
        String oper1 = operand1TextField.getText();
        String opera = operatorTextField.getText();
        String oper2 = operand2TextField.getText();
        
        
        if (opera.equals("+")){
            
            float add_result = Integer.parseInt(oper1) + Integer.parseInt(oper2);
            String last_result = String.valueOf(add_result);
            resultTextField.setText(last_result);
            
        } else if (opera.equals("-")){
            
            float sub_result = Integer.parseInt(oper1) - Integer.parseInt(oper2);
            String last_result = String.valueOf(sub_result);
            resultTextField.setText(last_result);           
        } else if (opera.equals("*")){
            
            float prod_result = Integer.parseInt(oper1) * Integer.parseInt(oper2);
            String last_result = String.valueOf(prod_result);
            resultTextField.setText(last_result);
        } else if (opera.equals("/")){
            
            float quo_result = Integer.parseInt(oper1) / Integer.parseInt(oper2);
            String last_result = String.valueOf(quo_result);
            resultTextField.setText(last_result);
        }else{
            System.out.println("Invalid");
        }
        
    }
    public static void main(String[] args){
        new Calculator().show();
    }
 
}
