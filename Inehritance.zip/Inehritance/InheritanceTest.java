public class InheritanceTest{
    public static void main(String[] args){
        Dog dog1 = new Dog();
        dog1.setColor("White");
        //dog1.setnumberLegs(3);
        dog1.setdogName("Whitey");
        
        System.out.println("My dog's name is " +dog1.getdogName()+ ". His color is " +dog1.getColor()+ " and he has " +dog1.getnumberLegs()+ " legs.");
    }
}