public class Animal{
    String _color;
    int _numberLegs; 
    
    public Animal(){
        
    }
    
    public Animal(String color, int numberLegs){
        this._color = color;
        this._numberLegs = numberLegs;
    }
    
    public String getColor(){
        return _color;
    }
    
    public void setColor(String color){
        this._color = color;
    }
    
    public int getnumberLegs(){
        return _numberLegs;
    }
    
    public void setnumberLegs(int numberLegs){
        this._numberLegs = numberLegs;
    }
    
    public void showInfo(){
        String color = getColor();
        int numberLegs = getnumberLegs();
        System.out.println("Color: " +color);
        System.out.println("Number of Legs: " +numberLegs);
    }
}