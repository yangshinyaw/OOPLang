public class Dog extends Animal{
    String _dogName;
    
    public Dog(){
        _numberLegs = 4;
    }
    
    public Dog(String color, int numberLegs, String dogName){
        _color = color;
        _numberLegs = numberLegs;
        _dogName = dogName;
    }
    
    public String getdogName(){
        return _dogName;
    }
    
    public void setdogName(String name){
        this._dogName = name;
    }
    
    public void dogInfo(){
        String dogName = getdogName();
    }
}